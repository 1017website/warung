/*
 * Tambahkan JavaScript global baru di file ini.
 * File dibaca langsung oleh browser sehingga tidak memerlukan npm run build.
 */
